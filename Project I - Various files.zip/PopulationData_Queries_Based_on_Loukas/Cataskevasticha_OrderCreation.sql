-- a. Create an order:

-- First, let's assume the customer ID and production employee ID are known
-- Let's assume the customer ID is 1 and the production employee ID is 1, also assume the logistics partner is FedEx.

-- Insert into the Orders table to create the order
INSERT INTO Orders (CustomerID, RequestDate, OrderStatus, ProductionEmployeeID, LogisticsPartner)
VALUES (1, GETDATE(), 1, 1, 'FedEx');

-- Now, let's insert into the OrderProductList table to specify the products and quantities for the order.
-- Let's assume the products ordered are 'BRK123', 'BLK456', and 'CON789' with quantities 100, 200, and 150 respectively.
INSERT INTO OrderProductList (OrderID, ProductSKU, ProductStatus, Quantity)
VALUES (SCOPE_IDENTITY(), 'BRK123', 'In Production', 100),
       (SCOPE_IDENTITY(), 'BLK456', 'In Production', 200),
       (SCOPE_IDENTITY(), 'CON789', 'In Production', 150);



-- b. Finalize production:

-- Assuming all products in an order are produced and ready for delivery
-- Update the ProductStatus in the OrderProductList table to 'Complete'
UPDATE OrderProductList
SET ProductStatus = 'Complete'
WHERE OrderID = order_id; -- Replace 'order_id' with the specific order ID for which production is finalized



-- c. Finalize an order and delivery:

-- Assuming the order is ready for delivery
-- Update the OrderStatus in the Orders table to 'Complete'
UPDATE Orders
SET OrderStatus = 3 -- Assuming 'Complete' corresponds to the value 3 in the OrderStatus column
WHERE OrderID = order_id; -- Replace 'order_id' with the specific order ID to be finalized and delivered