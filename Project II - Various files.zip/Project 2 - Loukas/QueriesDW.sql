----------------------------------------------------------------------

-- Which products are the most popular in terms of sales quantity ?
SELECT
	p.ProductName, 
	SUM(f.Quantity) AS TotalSales
FROM FactSales f
JOIN DimProduct p ON f.ProductKey = p.ProductKey
GROUP BY p.ProductName
ORDER BY TotalSales DESC;

----------------------------------------------------------------------

-- What is the contribution of each employee to the total sales ?
SELECT
    e.EmployeeName, 
    SUM(fs.TotalPrice) AS TotalSales, 
    FORMAT((SUM(fs.TotalPrice) / (SELECT SUM(TotalPrice) FROM FactSales)) * 100, 'N2') + ' %' AS Contribution
FROM FactSales fs
INNER JOIN DimEmployee e ON fs.EmployeeKey = e.EmployeeKey
GROUP BY e.EmployeeName
ORDER BY TotalSales DESC;

----------------------------------------------------------------------

-- Which customers are driving the most orders and what is their purchasing pattern over time ?
SELECT
    c.CustomerName,
    c.CustomerID,
    COUNT(f.OrderID) AS Orders,
    SUM(f.TotalPrice) AS TotalRevenue,
    d.quarter AS Quarter,
    d.year AS Year
FROM FactSales f
INNER JOIN DimCustomer c ON f.CustomerKey = c.CustomerKey
INNER JOIN DimDate d ON f.RequestDateKey = d.DateKey
GROUP BY 
    c.CustomerName,
    c.CustomerID,
    d.quarter,
    d.year
ORDER BY 
    COUNT(f.OrderID) DESC;

----------------------------------------------------------------------

-- Number of orders per quarter (revenues).
SELECT 
    d.quarter AS [Quarter],
    COUNT(f.OrderID) AS Orders
FROM FactSales f
INNER JOIN DimDate d ON f.RequestDateKey = d.DateKey
WHERE d.quarter IN (1, 2, 3, 4)  -- only consider quarters 1-4
GROUP BY d.quarter
ORDER BY d.quarter;

----------------------------------------------------------------------